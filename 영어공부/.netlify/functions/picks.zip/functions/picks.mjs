
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/picks.mjs
import { getStore } from "@netlify/blobs";
var CORS = { "Access-Control-Allow-Origin": "*", "Access-Control-Allow-Methods": "GET,POST,OPTIONS", "Access-Control-Allow-Headers": "Content-Type" };
var json = (body) => new Response(JSON.stringify(body), { headers: { ...CORS, "Content-Type": "application/json", "Cache-Control": "no-store" } });
var valid = (o) => o && typeof o.v === "string" && /^[\w-]{1,20}$/.test(o.v) && Number.isInteger(o.i) && o.i >= 0 && o.i < 1e5;
var picks_default = async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { status: 204, headers: CORS });
  const store = getStore({ name: "video-picks", consistency: "strong" });
  const picks = await store.get("picks", { type: "json" }) || [];
  if (req.method !== "POST") return json({ picks });
  const { ops } = await req.json().catch(() => ({}));
  if (!Array.isArray(ops) || ops.length > 500 || !ops.every(valid)) return new Response("bad ops", { status: 400, headers: CORS });
  for (const { v, i, on } of ops) {
    const at = picks.findIndex((p) => p.v === v && p.i === i);
    if (on && at < 0) picks.push({ v, i });
    if (!on && at >= 0) picks.splice(at, 1);
  }
  await store.setJSON("picks", picks);
  return json({ picks });
};
var config = { path: "/api/picks" };
export {
  config,
  picks_default as default
};
